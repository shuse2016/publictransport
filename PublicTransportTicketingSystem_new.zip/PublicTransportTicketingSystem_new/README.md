# README #

## Credentials for different Terminals ##

* Admin :    User:A123 Passowrd:123
* Passenger: User:P123 Passowrd:123
* Cashier:   User:C123 Passowrd:123
* Inspector: User:I123 Passowrd:123 [Pay Station Terminal]
* Driver:    User:D123 Passowrd:123
* Gate Operator: User:G123 Passowrd:123

### Quick Setup ###

* Open the project from Netbeans
* Run the project, if there is any errors;
* add DateChooser.jar libarary manually to the netbeans project structure

### How do I get set up? ###

* Summary of set up
* Configuration
* Dependencies
* Database configuration
* How to run tests
* Deployment instructions

### Contribution guidelines ###

* Writing tests
* Code review
* Other guidelines

### Who do I talk to? ###

* Repo owner or admin
* Other community or team contact