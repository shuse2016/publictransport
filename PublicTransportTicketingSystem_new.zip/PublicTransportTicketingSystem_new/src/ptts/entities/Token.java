
package ptts.entities;

import java.io.Serializable;
import java.util.ArrayList;

/**
 *
 * @author sachini
 */
public class Token implements Serializable{
    private String tokenID = null;
    private String passengerID = null;
    private String lastStation = null;
    private boolean isActive = true;
    private ArrayList<Ticket> activeTickets = new ArrayList<Ticket>();
    private boolean inUse = false;
    private float tokenBalance = 50.0f;
    
    public Token(String tokenID, String passengerID){
        this.tokenID = tokenID;
        this.passengerID = passengerID;
    }
    
    public String getTokenID() {
        return tokenID;
    }
    
    public String getLastStation() {
        return lastStation;
    }
    
    public String getPassengerID(){
        return passengerID;
    }

    public float  getTokenBalalce(){
        return tokenBalance;
    }
    
    public void setTokenID(String tokenID) {
        this.tokenID = tokenID;
    }

    public void setTokenBlance(float tokenBalance) {
        this.tokenBalance =  tokenBalance;
    }
    
    public void setinUse(boolean status) {
        this.inUse = status;
    } 
 
    public void setLastStation(String lastStation) {
        this.lastStation = lastStation;
    }
    
    public boolean isActive() {
        return isActive;
    }

    public boolean inUse() {
        return inUse;
    }
    
    public void setIsActive(boolean isActive) {
        this.isActive = isActive;
    }
    
    public void setInUse(boolean inUse) {
        this.inUse = inUse;
    }
    
    public void addTicket(Ticket ticket){
        activeTickets.add(ticket);
    }
    
    public ArrayList<Ticket> getActiveTicketList(){
        return this.activeTickets;
    }
    
    
    //*  Aditional Functionalities  ~ start *//
    
    private Ticket findTicketByID(String ticketID){
        Ticket tempTicket = null;
        for(int i=0; i< activeTickets.size(); i++){
            if(activeTickets.get(i).getTicketID().equals(ticketID)){
                tempTicket = activeTickets.get(i);
            }
        }
        return tempTicket;
    }
    
        private Ticket findTicketByPassenger(String passengerId){
        Ticket tempTicket = null;
        for(int i=0; i< activeTickets.size(); i++){
            if(activeTickets.get(i).getTicketID().equals(passengerId)){
                tempTicket = activeTickets.get(i);
            }
        }
        return tempTicket;
    }
    
    public Ticket removeTicketByID(String ticketID){
        Ticket tempTicket = null;

        for(int i=0; i< activeTickets.size(); i++){
            if(activeTickets.get(i).getTicketID().equals(ticketID)){
                tempTicket = activeTickets.get(i);
                activeTickets.remove(i);
            }
        }
        
        return tempTicket;
    }
    
    public Ticket removeTicket(Ticket ticket){
        Ticket tempTicket = activeTickets.get(activeTickets.indexOf(ticket));
        activeTickets.remove(ticket);
        return tempTicket;
    }

    
    
    
}
