
package ptts.services;

/**
 *
 * @author sachini
 */

 //PaymentGateWayConnection - Static Class
 
public class PaymentGateWayConnection {
    
}
